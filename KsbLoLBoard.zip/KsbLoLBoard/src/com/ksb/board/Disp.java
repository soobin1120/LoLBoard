package com.ksb.board;

import java.util.Scanner;

public class Disp {
	static private String TITLE_BAR="🎮🎮🎮🎮🎮🎮🎮🎮🎮🎮🎮🎮🎮🎮🎮🎮🎮🎮🎮🎮🎮🎮🎮🎮🎮🎮🎮🎮🎮🎮🎮🎮";
	static private String MAIN_TITLE="🎮🎮🎮🎮🎮🎮🎮🎮🎮🎮🎮🎮     포지션     🎮🎮🎮🎮🎮🎮🎮🎮🎮🎮🎮🎮";
	static private String POSITION_TITLE="🎮🎮🎮🎮🎮🎮🎮🎮🎮🎮🎮🎮     자유게시판     🎮🎮🎮🎮🎮🎮🎮🎮🎮🎮🎮🎮";
	static Scanner sc= new Scanner(System.in);
			
	public static void mainTitle() {
		System.out.println(TITLE_BAR);
		System.out.println(MAIN_TITLE);
		System.out.println(TITLE_BAR);
		
		
	}
	public static void positionTitle() {
		System.out.println(TITLE_BAR);
		System.out.println(POSITION_TITLE);
		System.out.println(TITLE_BAR);
	}
	public static void selectPosition() {
		System.out.println("탑/정글/미드/원딜/서폿");
	}
	public static void boardList() {
		System.out.println("1.목록/2.읽기/3.쓰기/4.삭제/5.수정/x.이전으로");
	}
	static public void reBoardList() {
		System.out.println("=============================================");
		System.out.println("1.목록/2.읽기/3.쓰기/4.삭제/5.수정/x.이전으로");
	}
}



