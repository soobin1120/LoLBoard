package com.ksb.board;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

import com.ksb.util.Db;

public class ProcSup {
	static Connection con = null;
	static Scanner sc=new Scanner(System.in);
	
	public static void run() {
		Db.tN="sup";
		Disp.positionTitle();
		Db.dbPostCount();
		Disp.boardList();
		System.out.println("명령입력:");
		loop:while(true) {
			String cmd= sc.next();
			switch(cmd) {
			case "1":
				System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
				System.out.println("~~~~~~~~~~     리스트     ~~~~~~~~~~");
				System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
				try {
					Db.result = Db.st.executeQuery("select*from "+Db.tN);
					while(Db.result.next()) {
						String no = Db.result.getString("k_no");
						String title = Db.result.getString("k_title");
						String id = Db.result.getString("k_id");
						String datetime = Db.result.getString("k_datetime");
						System.out.println(no+" "+title+" "+id+" "+datetime);
					}
				}catch(SQLException e){
					e.printStackTrace();
				}
				Disp.reBoardList();
				break;
			case "2":
				System.out.println("읽으실 게시글 번호를 선택해주세요");
				try {
					Db.result = Db.st.executeQuery("select*from "+Db.tN);
					while(Db.result.next()) {
						String no = Db.result.getString("k_no");
						String title = Db.result.getString("k_title");
						String id = Db.result.getString("k_id");
						String datetime = Db.result.getString("k_datetime");
						System.out.println(no+" "+title+" "+id+" "+datetime);
					}
				}catch(SQLException e){
					e.printStackTrace();
				}
				String readNo=sc.next();
				try {
					Db.result = Db.st.executeQuery("select * from "+Db.tN+" where k_no ="+readNo);
					Db.result.next();
					String title = Db.result.getString("k_title");
					String content = Db.result.getString("k_text");
					System.out.println("글제목: "+title);
					System.out.println("글내용: "+content);
				} catch (SQLException e) {
					e.printStackTrace();
				}
				Disp.reBoardList();
				break;
			case"3":
				sc.nextLine();
				System.out.println("제목을 입력하시오");
				String title=sc.nextLine();
				System.out.println("내용을 입력하시오");
				String content=sc.nextLine();
				System.out.println("작성자 이름을 입력하시오");
				String id=sc.nextLine();
				try {
					Db.st.executeUpdate("insert into "+Db.tN+" (k_title,k_id,k_datetime,k_text,k_hit)"
							+" values ('"+title+"','"+id+"',now(),'"+content+"',0)");
					System.out.println("글등록 완료");
				} catch (SQLException e) {
					e.printStackTrace();
				}			
				Disp.reBoardList();
				break;
			case"4":
				System.out.println("삭제하실 글번호를 입력하세요");
				try {
					Db.result = Db.st.executeQuery("select*from "+Db.tN);
					while(Db.result.next()) {
						String no = Db.result.getString("k_no");
						String title1 = Db.result.getString("k_title");
						String id1 = Db.result.getString("k_id");
						String datetime = Db.result.getString("k_datetime");
						System.out.println(no+" "+title1+" "+id1+" "+datetime);
					}
				}catch(SQLException e){
					e.printStackTrace();
				}
					String delNo=sc.next();
					Db.dbExecuteUpdate("delete from "+Db.tN+" where k_no="+delNo);
					Disp.reBoardList();
					break;
				
			case "5":
				System.out.println("수정하실 글 번호를 입력하시오");
				try {
					Db.result = Db.st.executeQuery("select*from "+Db.tN);
					while(Db.result.next()) {
						String no = Db.result.getString("k_no");
						String title1 = Db.result.getString("k_title");
						String id1 = Db.result.getString("k_id");
						String datetime = Db.result.getString("k_datetime");
						System.out.println(no+" "+title1+" "+id1+" "+datetime);
					}
				}catch(SQLException e){
					e.printStackTrace();
				}
				String editNo=sc.next();
				System.out.println("제목을 입력하시오");
				sc.nextLine();
				String edTitle=sc.nextLine();
				System.out.println("내용을 입력해주세요");
				String edContent =sc.next();
				System.out.println("작성자 이름을 적으세요");
				sc.nextLine();
				String edId=sc.nextLine();
				Db.dbExecuteUpdate("update "+Db.tN+" set k_title='"+edTitle+"',k_id='"+edId+"',k_datetime=now(),k_text='"+edContent+"' where k_no="+editNo);
				Disp.reBoardList();
				break;
			case"x":
				System.out.println("이전으로");
				break loop;
			}
				
			}
		}
		
	}


