package com.ksb.board;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

import com.ksb.util.Db;

public class ProcBoard {
	
	Scanner sc=new Scanner(System.in);
	
	
	void run() {
		Disp.mainTitle();
		Db.dbInit();
		Disp.selectPosition();
		loop:
			while(true) {
				System.out.println("포지션 선택:");
				String cmd=sc.next();
				switch(cmd) {
				case"탑":
					ProcTop.run();
					break;
				case"정글":
					ProcJug.run();
					break;
				case"미드":
					ProcMid.run();
					break;
				case"원딜":
					ProcAd.run();
					break;
				case"서폿":
					ProcSup.run();
					break;
				case"x":
					System.out.println("프로그램 종료");
					break loop;
				}
			}
	}

		
	}
	


