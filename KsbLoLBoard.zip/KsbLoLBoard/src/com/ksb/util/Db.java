package com.ksb.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Db {
	
	static Connection con=null;
	static public Statement st=null;
	public static ResultSet result=null;
	public static String tN=null;
	
	static public void dbInit() {
		try {
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/ksb", "root", "root");
			st = con.createStatement();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	static public void dbExecuteUpdate(String query) {
		try {
			int resultCount = st.executeUpdate(query);
			System.out.println("처리된 행 수:"+resultCount);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	static public void dbPostCount() {	
		try {
			result = st.executeQuery("select count(*) from "+tN);
			result.next();
			String count = result.getString("count(*)");
			System.out.println("글 수:"+count);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
}
