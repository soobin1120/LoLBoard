/**
 * 
 */
/**
 * @author GDJ59
 *
 */
module KsbCustomerBoard {
	requires java.sql;
}